# Changelog

## v1.0.1 (2026-11-01)

- Fixed a crash when loading into a free mode battle. The mod rebuilt the list on every level change, while the game was still unloading equipment data. Now the list is built once, while the loadout screen exists, and the screen hook keeps it in place after that.
- Pressing F6 outside the free mode menu now waits for the loadout screen before building the list.

## v1.0.0 (2026-10-31)

First release.

- The free mode loadout screen lists every armor piece and weapon the game has data for, including color and material variants.
- Grouped by type: armor head to feet, weapons by kind. A-Z within each group.
- F6 toggles the full list on and off and restores the original list. Shift+F5 writes the sorted list to the log.
- Hooks the loadout screen, so the full list survives the game rebuilding the inventory each time the screen opens.
- All changes are in memory only; save files are never modified.
