# FullLoadoutList

A [UE4SS](https://github.com/UE4SS-RE/RE-UE4SS) Lua mod for **Half Sword** that replaces the item list on the **free mode loadout screen** with every armor piece and weapon in the game, grouped by type and sorted alphabetically.

## What it does

- **Every item, not a random selection.** The loadout list normally shows your tier's random selection plus items from progression mode. With the mod, it lists every armor piece and weapon the game has data for, from every tier, including the pre-made weapons.
- **Color and material variants included.** Each color, steel type, finish and part combination gets its own entry. Only exact duplicates are removed.
- **Sorted by type, then A-Z.**
  - Armor, head to feet: Head, Neck, Shoulders, Body, Chest, Arms, Hands, Waist, Legs, Feet.
  - Weapons: Axes, Daggers, Maces & Flails, Polearms, Shields, Staves, Swords, Tools, Other.
- **Toggle with F6.** Turning it off brings back the game's normal list.
- **Save-safe.** All changes are in memory only. The mod never writes to your save files, and removing it gives you the vanilla list back.

## Requirements

- Half Sword (UE5 version)
- [UE4SS](https://github.com/UE4SS-RE/RE-UE4SS) **v3.0.1** or newer, installed in `Half Sword\HalfswordUE5\Binaries\Win64\`

## Install

1. Install UE4SS for Half Sword if you haven't yet.
2. Copy the `FullLoadoutList` folder into:
   ```
   Half Sword\HalfswordUE5\Binaries\Win64\ue4ss\Mods\
   ```
3. Make sure the mod is enabled. The folder contains an `enabled.txt`, which turns it on. Alternatively, add this line to `ue4ss\Mods\mods.txt`:
   ```
   FullLoadoutList : 1
   ```
4. Start the game, go into free mode, and open the loadout screen.

## Controls

| Key | Action |
|-----|--------|
| **F6** | Turn the full list on or off (an on-screen message confirms it). Reopen the loadout screen to see the change. |
| **Shift+F5** | Write the full sorted list to `ue4ss\UE4SS.log` |

## Configuration

All settings are in `FullLoadoutList\Scripts\config.lua`, with comments explaining each one. Restart the game after editing.

| Setting | What it changes |
|---------|-----------------|
| `StartEnabled` | `false` = start with the normal list; press F6 to switch |
| `KeepVariants` | `false` = one entry per model, without color and material variants |
| `ArmorGroupOrder` | Order of the armor groups (`nil` = alphabetical) |
| `WeaponGroups` | Which keywords put a weapon in which group |
| `WeaponGroupOrder` | Order of the weapon groups (`nil` = alphabetical) |
| `Keys` | Key bindings |

## How it works

The loadout screen builds its list from the free mode inventory. The game rebuilds that inventory from the tier's item list (plus progression items) every time the screen opens. The mod:

1. Collects every armor and weapon entry from the game's equipment data (all tiers, slots, pre-made weapons and loadouts).
2. Removes exact duplicates and sorts the rest.
3. Writes the result into the free mode inventory and the current tier's item list, keeping backups of both.
4. Hooks the loadout screen, so the full list is in place right before the screen builds it.

F6 off restores both backups.

## Notes

- **Item coverage:** the list contains everything the game has loaded once you're in free mode. That covers all equipment tiers, but items that exist only in data the game never loads won't appear.
- **List length:** with variants on, the list is long (about 160 armor entries and 140 weapons). Set `KeepVariants = false` for a shorter list.
- **Repeated names:** some entries share a name, for example several longswords with the same blade. They differ in guard, pommel, grip, size or materials.

## Troubleshooting

Look at the end of `ue4ss\UE4SS.log` for lines starting with `[FullLoadoutList]`.

- A healthy start shows `Applied (auto): armor ... -> ..., weapons ... -> ...` once free mode loads.
- Any line containing `failed` is an error. Please include those lines when reporting a problem.

## License

[MIT](LICENSE): free for anyone to use, modify and share, as long as the license notice is kept.
