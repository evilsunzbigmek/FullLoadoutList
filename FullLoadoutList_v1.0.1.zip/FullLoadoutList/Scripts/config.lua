-- FullLoadoutList settings
return {
    StartEnabled = true,

    Keys = {
        Toggle = Key.F6,                      -- full loadout on/off
        Scan = Key.F5,                        -- Shift+F5: write what the mod found to UE4SS.log
        ScanModifiers = { ModifierKey.SHIFT },
    },

    -- Where the free mode loadout screen reads its list from (found by scanning the game).
    InventoryVar = "Free Mode Player Inventory",   -- on the GameInstance (GI_Settings_C)
    ScreenClass = "UI_Tavern_Inventory_C",         -- the loadout screen
    FreeModeAssetVar = "DA Free Mode Inventory",   -- GameInstance var pointing at the tier's data asset
    -- Backup of your original inventory: the "Inventory" var on the class defaults of this asset class.
    BackupClass = "DA_FreeMode_Inventory_C",
    BackupVar = "Inventory",
    -- Loadout screen functions hooked: before each runs, the mod makes sure the full list is in place.
    -- Calls are logged (up to ScreenHookLogLimit per screen opening) to see where the game rebuilds the list.
    ScreenHookFunctions = { "Construct", "Get Player Inventory", "PreConstruct" },
    ScreenHookLogLimit = 0,       -- 0 = quiet; raise (e.g. 6) to debug the screen

    -- Sources of gear: every loaded data asset of these classes, plus these GameInstance variables.
    SourceAssetClasses = {
        "DA_FreeMode_Inventory_C",
        "DA_Equipment_Armor_Master_C",
        "DA_Equipment_Loadout_Master_C",
        "DA_Equipment_Weapons_PreMade_Master_C",
        "DA_Equipment_Weapons_Types_Master_C",
        "DA_Equipment_Weapons_Modules_Master_C",
    },
    ExtraGameInstanceVars = {
        "Available Custom Armor", "Available Weapons 1H", "Available Weapons 2H", "Available Shields",
        "Player Inventory", "Merchant Inventory", "Free Mode Player Character 1",
        "Free Mode Player Character 2", "Player Character",
    },

    -- true: every color/material/size variant is its own entry (only exact copies are dropped).
    -- false: one entry per model (armor: piece + modules, weapons: class + name + parts).
    KeepVariants = true,
    -- Fields compared to tell variants apart (field name prefixes inside the game's item structs).
    ArmorVariantFields = { "CoreRemoved", "Module1", "Module2", "Module3", "LeatherColor", "FabricColor1",
                           "FabricColor2", "FabricColor3", "SteelType", "MetalPiecesType", "RustToggle",
                           "DirtToggle" },
    WeaponVariantFields = { "Name", "HeadModule", "HeadSubModule1", "HeadSubModule2", "GuardModule",
                            "PommelModule", "GripModule", "HeadSize", "GuardSize", "GripSize", "PommelSize",
                            "CustomMassScaleHead", "CustomMassScaleGuard", "CustomMassScaleGrip",
                            "CustomMassScalePommel", "MaterialMetalSteel", "MaterialMetalColored",
                            "MaterialWeood", "MaterialLeather", "ColorWood", "ColorLeather" },

    -- Weapon types: first rule whose keyword appears in the weapon's class/name/head part wins.
    WeaponGroups = {
        { "Tools",          { "tool_", "scythe", "pitchfork", "improv" } },
        { "Shields",        { "shield", "buckler", "pavise", "tagre" } },
        { "Daggers",        { "dagger", "rondel" } },
        { "Polearms",       { "pollaxe", "halberd", "polearm", "spear", "glaive", "baronbeak", "billhook" } },
        { "Axes",           { "axe" } },
        { "Maces & Flails", { "mace", "flail", "hammer", "club", "morning" } },
        { "Staves",         { "staff" } },
        { "Swords",         { "sword", "falchion", "messer", "blade", "baurnwehr", "bauernwehr" } },
    },

    -- Order of the type groups. nil = alphabetical. Example for armor in body order:
    -- ArmorGroupOrder = { "Head", "Neck", "Shoulders", "Chest", "Body", "Arms", "Hands", "Waist", "Legs", "Feet" },
    ArmorGroupOrder = { "Head", "Neck", "Shoulders", "Body", "Chest", "Arms", "Hands", "Waist", "Legs", "Feet" },
    WeaponGroupOrder = nil,

    ShowToast = true,
    ToastSeconds = 2.5,
}
