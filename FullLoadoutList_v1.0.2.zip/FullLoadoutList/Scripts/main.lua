-- FullLoadoutList v1.0.2 for Half Sword (UE4SS Lua mod)
-- Free mode loadout screen: lists every armor piece and weapon the game has loaded (including color
-- and material variants), grouped by type and sorted A-Z. F6 on/off (off puts your original list back).
-- Shift+F5 writes the sorted list to UE4SS.log.
--
-- How it works: the loadout screen (UI_Tavern_Inventory_C) builds its list from the game instance's
-- "Free Mode Player Inventory" (armor passports + weapon passports), which the game rebuilds from the
-- tier data asset (DA_FreeMode_Inventory_Tier_*) plus progression items each time the screen opens.
-- We collect every passport from the equipment data assets and game instance lists, drop exact copies,
-- sort, and write the result into the free mode inventory and the tier data asset. A hook on the
-- screen's "Get Player Inventory" puts the full list back in place right before the screen builds.
-- All changes are in memory only; nothing is written to save files.
--
-- Safety rules learned the hard way (each one crashed the game when broken):
--  * items are only copied struct-to-struct (never written from Lua tables);
--  * Lua garbage is collected before any game list is changed (flushLua);
--  * only known-safe passport fields are read for the variant check.

local Cfg = require("config")
local TAG = "[FullLoadoutList] "
local function log(msg) print(TAG .. tostring(msg) .. "\n") end

-- Lua handles that point into game lists must be cleaned up while those lists still exist; cleaning
-- them up after a list was rebuilt crashes the game. So: full cleanup right before
-- any list is changed.
local function flushLua() collectgarbage("collect") end
-- Automatic cleanup is off: it could start while UE4SS was in the middle of walking the game's item data
-- (inside ForEachProperty callbacks), which crashed the game (v1.0.1, opening the loadout screen). Cleanup
-- now only runs at safe points: start of each loop tick, after each screen hook and key press, and
-- before any list change.
collectgarbage("stop")

local enabled = Cfg.StartEnabled ~= false
local state = {
    applied = false,      -- our list is in the inventory
    backedUp = false,     -- your original inventory is saved in the backup slot
    daObj = nil,          -- tier data asset we filled (its original list is in the GameInstance defaults)
    expected = nil,       -- { armor = n, weapon = n } counts we wrote
}

---------------------------------------------------------------------------
-- helpers
---------------------------------------------------------------------------
local function valid(o)
    if o == nil then return false end
    local ok, r = pcall(function() return o:IsValid() end)
    return ok and r
end

local function safe(label, fn, ...)
    local ok, err = pcall(fn, ...)
    if not ok then log(label .. " failed: " .. tostring(err)) end
    return ok, err
end

local function nameOf(o)
    local ok, n = pcall(function() return o:GetFName():ToString() end)
    return ok and n or "?"
end

local function classNameOf(o)
    local ok, n = pcall(function() return o:GetClass():GetFName():ToString() end)
    return ok and n or "?"
end

local function addr(o)
    local ok, a = pcall(function() return o:GetAddress() end)
    return ok and a or nil
end

local function propType(p)
    local ok, n = pcall(function() return p:GetClass():GetFName():ToString() end)
    return ok and n or "?"
end

local function superOf(c)
    local s = nil
    pcall(function() s = c:GetSuperStruct() end)
    return valid(s) and s or nil
end

local function textOf(v)
    if v == nil then return nil end
    if type(v) == "string" then return v ~= "" and v or nil end
    local ok, s = pcall(function() return v:ToString() end)
    if ok and type(s) == "string" and s ~= "" and s ~= "None" then return s end
    return nil
end

local function unwrap(v)
    if type(v) == "userdata" then
        local ok, g = pcall(function() return v:get() end)
        if ok and g ~= nil then return g end
    end
    return v
end

local function arrNum(arr)
    local ok, n = pcall(function() return arr:GetArrayNum() end)
    return ok and n or 0
end

local function structOf(prop)
    local s = nil
    pcall(function() s = prop:GetStruct() end)
    return s
end

local function eachField(ustruct, fn)
    local cur, d = ustruct, 0
    while valid(cur) and d < 6 do
        pcall(function()
            cur:ForEachProperty(function(p)
                local ok, e = pcall(fn, p)
                if not ok then log("  field " .. nameOf(p) .. ": " .. tostring(e)) end
            end)
        end)
        cur, d = superOf(cur), d + 1
    end
end

-- Blueprint struct fields are named like "ArmorCore_3_F6B7C69C..."; the prefix is "ArmorCore".
local function prefixOf(n)
    return string.match(n, "^(.-)_%d+_%x+$") or n
end

local function fieldMap(ustruct)
    local m = {}
    eachField(ustruct, function(f) m[prefixOf(nameOf(f))] = nameOf(f) end)
    return m
end

local function findProp(obj, pname)
    local found, cls, d = nil, nil, 0
    pcall(function() cls = obj:GetClass() end)
    while valid(cls) and d < 10 and not found do
        pcall(function()
            cls:ForEachProperty(function(p) if not found and nameOf(p) == pname then found = p end end)
        end)
        cls, d = superOf(cls), d + 1
    end
    return found
end

local function readField(v, full)
    if not full then return nil end
    local ok, x = pcall(function() return v[full] end)
    if ok then return unwrap(x) end
    return nil
end

local function clsName(x) return valid(x) and nameOf(x) or "" end

---------------------------------------------------------------------------
-- passport layout (read from the game's own inventory struct)
---------------------------------------------------------------------------
local L = nil  -- layout
local function layout(gi)
    if L then return L end
    local p = findProp(gi, Cfg.InventoryVar)
    if not p then error("GameInstance has no '" .. Cfg.InventoryVar .. "'") end
    local inv = structOf(p)
    local l = { invProp = p }
    eachField(inv, function(f)
        local pre = prefixOf(nameOf(f))
        local inner = nil
        pcall(function() inner = f:GetInner() end)
        if pre == "ArmorPassports" then l.armorField, l.armorInner = nameOf(f), inner end
        if pre == "WeaponPssports" or pre == "WeaponPassports" then l.weaponField, l.weaponInner = nameOf(f), inner end
    end)
    if not (l.armorField and l.weaponField) then error("inventory struct layout not recognized") end
    l.armorStruct = nameOf(structOf(l.armorInner))
    l.weaponStruct = nameOf(structOf(l.weaponInner))
    l.AF = fieldMap(structOf(l.armorInner))
    l.WF = fieldMap(structOf(l.weaponInner))
    log("Layout: armor " .. l.armorStruct .. ", weapons " .. l.weaponStruct)
    L = l
    return l
end

---------------------------------------------------------------------------
-- naming and sorting
---------------------------------------------------------------------------
local function clean(n)
    n = string.gsub(n or "", "_C$", "")
    return n
end

local function armorGroupLabel(core, m1, m2, m3)
    local s = clean(core)
    local rest = string.match(s, "Core_(.+)$") or string.gsub(s, "^BP_Armor_", "")
    local region, tail = string.match(rest, "^([^_]+)_(.+)$")
    if not region then region, tail = "Other", rest end
    local label = string.gsub(tail, "_", " ")
    if (m1 or 0) ~= 0 or (m2 or 0) ~= 0 or (m3 or 0) ~= 0 then
        label = label .. string.format(" (variant %d-%d-%d)", m1 or 0, m2 or 0, m3 or 0)
    end
    return region, label
end

local function shortModule(n)
    n = clean(n)
    for _, p in ipairs({ "Modular_", "Weapon_Part_", "Weapon_Module_", "Weapon_" }) do
        if string.sub(n, 1, #p) == p then n = string.sub(n, #p + 1) end
    end
    return (string.gsub(n, "_", " "))
end

local function weaponGroupLabel(wc, name, head)
    local base = clean(wc)
    base = string.gsub(base, "^ModularWeaponBP_?", "")
    base = string.gsub(base, "^BP_Weapon_", "")
    base = string.gsub(base, "_", " ")
    local label = name ~= "" and name or (base ~= "" and base or "Weapon")
    if head ~= "" then label = label .. " (" .. shortModule(head) .. ")" end
    local all = string.lower(wc .. " " .. name .. " " .. head)
    local group = "Other"
    for _, rule in ipairs(Cfg.WeaponGroups) do
        local hit = false
        for _, k in ipairs(rule[2]) do
            if string.find(all, k, 1, true) then hit = true; break end
        end
        if hit then group = rule[1]; break end
    end
    return group, label
end

-- Fingerprint of a passport's look/build fields (Cfg.ArmorVariantFields / WeaponVariantFields: colors,
-- steel type, materials, sizes...), so variants of the same piece count as different items.
-- Only these known field types are read: reading every field crashes the game inside UE4SS.
local NUMERIC_SUB = { FloatProperty = true, DoubleProperty = true }
local function fingerprint(v, fieldList, fmap)
    local parts = {}
    for _, pre in ipairs(fieldList) do
        local full = fmap.names[pre]
        local t = fmap.types[pre]
        local s = ""
        if full then
            local x = readField(v, full)
            if t == "StructProperty" then
                local sub = {}
                eachField(fmap.structs[pre], function(sf)
                    if NUMERIC_SUB[propType(sf)] then
                        local n = readField(x, nameOf(sf))
                        sub[#sub + 1] = type(n) == "number" and string.format("%.3f", n) or "?"
                    end
                end)
                s = table.concat(sub, "/")
            elseif type(x) == "number" then
                s = string.format("%.3f", x)
            elseif type(x) == "boolean" then
                s = x and "1" or "0"
            elseif t == "ObjectProperty" or t == "ClassProperty" then
                s = clsName(x)
            elseif t == "NameProperty" then
                s = textOf(x) or ""
            end
        end
        parts[#parts + 1] = s
    end
    return table.concat(parts, ",")
end

-- field prefix -> full name / property type / struct, for one passport struct
local function fieldInfo(ustruct)
    local m = { names = {}, types = {}, structs = {} }
    eachField(ustruct, function(f)
        local pre = prefixOf(nameOf(f))
        m.names[pre] = nameOf(f)
        m.types[pre] = propType(f)
        if m.types[pre] == "StructProperty" then m.structs[pre] = structOf(f) end
    end)
    return m
end

local function makeRecord(kind, v)
    local l = L
    if kind == "armor" then
        local core = clsName(readField(v, l.AF.ArmorCore))
        if core == "" then return nil end
        local m1 = tonumber(readField(v, l.AF.Module1)) or 0
        local m2 = tonumber(readField(v, l.AF.Module2)) or 0
        local m3 = tonumber(readField(v, l.AF.Module3)) or 0
        local group, label = armorGroupLabel(core, m1, m2, m3)
        local key = core .. "|" .. m1 .. "|" .. m2 .. "|" .. m3
        if Cfg.KeepVariants then
            l.AFI = l.AFI or fieldInfo(structOf(l.armorInner))
            key = core .. "|" .. fingerprint(v, Cfg.ArmorVariantFields, l.AFI)
        end
        return { kind = kind, keyClass = core, key = key, group = group, label = label }
    else
        local wc = clsName(readField(v, l.WF.WeaponClass))
        if wc == "" then return nil end
        local name = textOf(readField(v, l.WF.Name)) or ""
        local parts = { wc, name }
        for _, f in ipairs({ "HeadModule", "HeadSubModule1", "HeadSubModule2", "GuardModule", "PommelModule", "GripModule" }) do
            parts[#parts + 1] = clsName(readField(v, l.WF[f]))
        end
        local group, label = weaponGroupLabel(wc, name, parts[3])
        local key = table.concat(parts, "|")
        if Cfg.KeepVariants then
            l.WFI = l.WFI or fieldInfo(structOf(l.weaponInner))
            key = wc .. "|" .. fingerprint(v, Cfg.WeaponVariantFields, l.WFI)
        end
        return { kind = kind, keyClass = wc, key = key, group = group, label = label }
    end
end

local function groupRank(kind, g)
    local order = kind == "armor" and Cfg.ArmorGroupOrder or Cfg.WeaponGroupOrder
    if order then
        for i, x in ipairs(order) do if x == g then return i end end
        return 1000
    end
    return 0
end

local function sortRecords(list)
    table.sort(list, function(a, b)
        local ra, rb = groupRank(a.kind, a.group), groupRank(b.kind, b.group)
        if ra ~= rb then return ra < rb end
        local ga, gb = string.lower(a.group), string.lower(b.group)
        if ga ~= gb then return ga < gb end
        local la, lb = string.lower(a.label), string.lower(b.label)
        if la ~= lb then return la < lb end
        return a.key < b.key
    end)
    return list
end

---------------------------------------------------------------------------
-- collecting every passport the game has loaded
-- Items are only ever copied the game's own way (whole struct to struct). Writing from Lua tables
-- crashes the game, so every record keeps a reference to a game struct instead.
---------------------------------------------------------------------------
-- origObj/origProp: where the "current inventory" passports are read from (listed first, so items you
-- already have keep their colors). Defaults to the live free mode inventory.
local function collect(gi, origObj, origProp)
    local l = layout(gi)
    origObj, origProp = origObj or gi, origProp or l.invProp
    local cat = { armor = {}, weapon = {} }
    local byKey = { armor = {}, weapon = {} }
    local stats = { sources = 0, seen = 0 }

    local function visit(kind, v)
        stats.seen = stats.seen + 1
        local rec = makeRecord(kind, v)
        if not rec or byKey[kind][rec.key] then return end
        rec.ref = v
        byKey[kind][rec.key] = rec
        table.insert(cat[kind], rec)
    end

    local walk
    walk = function(v, prop, depth)
        if v == nil or depth > 8 then return end
        local t = propType(prop)
        if t == "StructProperty" then
            local sn = nameOf(structOf(prop))
            if sn == l.armorStruct then visit("armor", v); return end
            if sn == l.weaponStruct then visit("weapon", v); return end
            eachField(structOf(prop), function(f)
                local ok, fv = pcall(function() return v[nameOf(f)] end)
                if ok then walk(unwrap(fv), f, depth + 1) end
            end)
        elseif t == "ArrayProperty" then
            local inner = nil
            pcall(function() inner = prop:GetInner() end)
            if not inner then return end
            local it = propType(inner)
            if it ~= "StructProperty" and it ~= "MapProperty" and it ~= "ArrayProperty" then return end
            for i = 1, arrNum(v) do
                local e = nil
                pcall(function() e = v[i] end)
                walk(unwrap(e), inner, depth + 1)
            end
        elseif t == "MapProperty" then
            local vp = nil
            pcall(function() vp = prop:GetValueProp() end)
            if not vp then return end
            local vt = propType(vp)
            if vt ~= "StructProperty" and vt ~= "ArrayProperty" then return end
            pcall(function()
                v:ForEach(function(_, val) walk(unwrap(val), vp, depth + 1) end)
            end)
        end
    end

    local function walkObjectProp(obj, p)
        local ok, v = pcall(function() return obj[nameOf(p)] end)
        if ok and v ~= nil then
            stats.sources = stats.sources + 1
            walk(unwrap(v), p, 0)
        end
    end

    -- 1) the current free mode inventory (or its backup) first
    walkObjectProp(origObj, origProp)
    -- 2) other game instance lists (progression inventory, unlocked lists, equipped gear)
    for _, pn in ipairs(Cfg.ExtraGameInstanceVars) do
        local p = findProp(gi, pn)
        if p then walkObjectProp(gi, p) end
    end
    -- 3) every equipment data asset
    for _, cn in ipairs(Cfg.SourceAssetClasses) do
        for _, o in ipairs(FindAllOf(cn) or {}) do
            if valid(o) and not string.find(nameOf(o), "Default__", 1, true) then
                local cls, d = nil, 0
                pcall(function() cls = o:GetClass() end)
                while valid(cls) and d < 6 and string.find(nameOf(cls), "_C", -2, true) do
                    pcall(function()
                        cls:ForEachProperty(function(p)
                            if nameOf(p) ~= "UberGraphFrame" then walkObjectProp(o, p) end
                        end)
                    end)
                    cls, d = superOf(cls), d + 1
                end
            end
        end
    end
    sortRecords(cat.armor)
    sortRecords(cat.weapon)
    return cat, stats
end

---------------------------------------------------------------------------
-- backup of your original free mode inventory
-- Kept in the class defaults of DA_FreeMode_Inventory_C: it has an "Inventory" struct of the same
-- type, nothing in the game reads it, and it is never garbage collected.
---------------------------------------------------------------------------
local function inventoryArrays(gi)
    local l = layout(gi)
    local inv = gi[Cfg.InventoryVar]
    return inv[l.armorField], inv[l.weaponField]
end

local function backupStore(gi)
    local da = nil
    pcall(function() da = gi[Cfg.FreeModeAssetVar] end)
    if not valid(da) then da = FindFirstOf(Cfg.BackupClass) end
    if not valid(da) then error("no " .. Cfg.BackupClass .. " loaded") end
    local cdo = nil
    pcall(function() cdo = da:GetClass():GetCDO() end)
    if not valid(cdo) then error("class defaults of " .. classNameOf(da) .. " not found") end
    local p = findProp(cdo, Cfg.BackupVar)
    if not p or nameOf(structOf(p)) ~= nameOf(structOf(layout(gi).invProp)) then
        error("backup slot '" .. Cfg.BackupVar .. "' has the wrong type")
    end
    return cdo, p
end

local function storeArrays(store)
    local l = L
    local inv = store[Cfg.BackupVar]
    return inv[l.armorField], inv[l.weaponField]
end

-- whole-inventory copy, the game's way; returns true if both lists ended up the same size
local function copyInventory(dstObj, dstVar, srcObj, srcVar)
    flushLua()
    local src = srcObj[srcVar]
    dstObj[dstVar] = src
    local s, d = srcObj[srcVar], dstObj[dstVar]
    local l = L
    return arrNum(s[l.armorField]) == arrNum(d[l.armorField])
       and arrNum(s[l.weaponField]) == arrNum(d[l.weaponField])
end

-- GameInstance class defaults: unused at runtime; holds the tier data asset's original list.
local function giDefaults(gi)
    local cdo = nil
    pcall(function() cdo = gi:GetClass():GetCDO() end)
    if valid(cdo) and findProp(cdo, Cfg.InventoryVar) then return cdo end
    return nil
end

local function invCounts(obj, var)
    local a, w = -1, -1
    pcall(function()
        local inv = obj[var]
        a, w = arrNum(inv[L.armorField]), arrNum(inv[L.weaponField])
    end)
    return a, w
end

---------------------------------------------------------------------------
-- writing the inventory
---------------------------------------------------------------------------
-- Appends rec at the end of arr (or overwrites index `at`). No read-back: a Lua handle to an element of
-- a list that is still growing would point at freed memory after the next append.
local function putRecord(arr, rec, at)
    local idx = at or (arrNum(arr) + 1)
    local ok, err = pcall(function() arr[idx] = rec.ref end)
    if not ok then return nil, tostring(err) end
    if arrNum(arr) < idx then return nil, "array did not grow" end
    return true
end

-- Replaces the array contents with `list`. Returns written count, stats string.
local function rewrite(arr, list, label)
    flushLua()
    local n0 = arrNum(arr)
    if #list == 0 then return n0, "nothing to write" end
    local emptied = pcall(function() arr:Empty() end) and arrNum(arr) == 0
    local written, failed = 0, 0
    for i, rec in ipairs(list) do
        local ok, e = putRecord(arr, rec, (not emptied and i <= arrNum(arr)) and i or nil)
        if ok then
            written = written + 1
        else
            failed = failed + 1
            if failed <= 5 then log("  " .. label .. ": failed to add " .. rec.label .. ": " .. tostring(e)) end
            if failed >= 5 and written == 0 then log("  " .. label .. ": giving up"); break end
        end
    end
    local s = "added " .. written
    if failed > 0 then s = s .. ", failed " .. failed end
    if not emptied then s = s .. ", Empty() unavailable: overwrote in place" end
    return arrNum(arr), s
end

local function gameInstance()
    local gi = FindFirstOf("GameInstance")
    if valid(gi) and findProp(gi, Cfg.InventoryVar) then return gi end
    return nil
end

-- The free mode tier data asset (e.g. DA_FreeMode_Inventory_Tier_Knight). The loadout screen seems to
-- rebuild the inventory from it (plus progression items) when it opens, so it gets the full list too.
-- Its original list is backed up in the GameInstance class defaults (unused at runtime).
local function currentTierAsset(gi)
    local da = nil
    pcall(function() da = gi[Cfg.FreeModeAssetVar] end)
    if valid(da) and findProp(da, Cfg.BackupVar) then return da end
    return nil
end

local function restoreTierAsset(gi)
    if state.daObj and valid(state.daObj) then
        local cdo = giDefaults(gi)
        if cdo then
            copyInventory(state.daObj, Cfg.BackupVar, cdo, Cfg.InventoryVar)
            log(string.format("Restored %s: %d armor, %d weapons", nameOf(state.daObj), invCounts(state.daObj, Cfg.BackupVar)))
        end
    end
    state.daObj = nil
end

local function restore()
    local gi = gameInstance()
    if not gi then
        state.applied, state.expected, state.backedUp = false, nil, false
        return false
    end
    if state.backedUp then
        local store = backupStore(gi)
        local ok = copyInventory(gi, Cfg.InventoryVar, store, Cfg.BackupVar)
        local ra, rw = invCounts(gi, Cfg.InventoryVar)
        log(string.format("Restored original free mode inventory: %d armor, %d weapons%s",
            ra, rw, ok and "" or " (size check failed!)"))
    end
    restoreTierAsset(gi)
    state.applied, state.expected, state.backedUp = false, nil, false
    return true
end

local function apply(reason)
    local gi = gameInstance()
    if not gi then return false end
    local armorArr, weaponArr = inventoryArrays(gi)
    local na0, nw0 = arrNum(armorArr), arrNum(weaponArr)
    -- the game fills the free mode inventory when free mode loads; before that it's empty: don't touch it
    if na0 + nw0 == 0 then return false end
    local store, storeProp = backupStore(gi)
    if not state.backedUp then
        if not copyInventory(store, Cfg.BackupVar, gi, Cfg.InventoryVar) then
            log("Backup of your free mode inventory failed; not changing anything")
            return false
        end
        state.backedUp = true
        log(string.format("Backed up your free mode inventory (%d armor, %d weapons)", na0, nw0))
    end
    local t0 = os.clock()
    -- read your items from the backup, so the live lists can be cleared and refilled safely
    local cat, stats = collect(gi, store, storeProp)
    armorArr, weaponArr = inventoryArrays(gi)
    local na, sa = rewrite(armorArr, cat.armor, "Armor")
    armorArr, weaponArr = inventoryArrays(gi)
    local nw, sw = rewrite(weaponArr, cat.weapon, "Weapons")
    cat = nil
    flushLua()  -- drop handles into the data assets before the tier asset gets rewritten
    state.applied = true
    state.expected = { armor = na, weapon = nw }
    log(string.format("Applied (%s): armor %d -> %d [%s], weapons %d -> %d [%s]; %d sources, %d passports seen, %.0f ms",
        reason, na0, na, sa, nw0, nw, sw, stats.sources, stats.seen, (os.clock() - t0) * 1000))
    -- same list into the current tier data asset
    local da = currentTierAsset(gi)
    if not da then
        log("  tier data asset '" .. Cfg.FreeModeAssetVar .. "' not found")
        return true
    end
    if state.daObj and addr(state.daObj) ~= addr(da) then restoreTierAsset(gi) end
    if not state.daObj then
        local cdo = giDefaults(gi)
        if cdo and copyInventory(cdo, Cfg.InventoryVar, da, Cfg.BackupVar) then
            state.daObj = da
            log(string.format("  backed up %s (%d armor, %d weapons)", nameOf(da), invCounts(da, Cfg.BackupVar)))
        else
            log("  backup of " .. nameOf(da) .. " failed; leaving it alone")
        end
    end
    if state.daObj then
        copyInventory(da, Cfg.BackupVar, gi, Cfg.InventoryVar)
        log(string.format("  %s now %d armor, %d weapons", nameOf(da), invCounts(da, Cfg.BackupVar)))
    end
    return true
end

-- A live loadout screen (not the class defaults). The list is only ever built while one exists, i.e. in
-- the free mode menu, never while a battle level loads: equipment data can be unloading then, and
-- copying an item out of it crashed the game (v1.0.0, loading into a free mode battle).
local function screenExists()
    for _, w in ipairs(FindAllOf(Cfg.ScreenClass) or {}) do
        if valid(w) and not string.find(nameOf(w), "Default__", 1, true) then return true end
    end
    return false
end

local function screenOpen()
    for _, w in ipairs(FindAllOf(Cfg.ScreenClass) or {}) do
        if valid(w) and not string.find(nameOf(w), "Default__", 1, true) then
            local ok, inVp = pcall(function() return w:IsInViewport() end)
            if ok and inVp then return true end
        end
    end
    return false
end

---------------------------------------------------------------------------
-- scan (Shift+F5): what the mod finds, in the order it would list it
---------------------------------------------------------------------------
local function scan()
    log("================ FullLoadoutList scan ================")
    local gi = gameInstance()
    if not gi then log("No GameInstance with " .. Cfg.InventoryVar); return end
    local cat, stats = collect(gi)
    local armorArr, weaponArr = inventoryArrays(gi)
    log(string.format("Inventory now: %d armor, %d weapons. Mod %s (applied: %s, backed up: %s)",
        arrNum(armorArr), arrNum(weaponArr), enabled and "ON" or "OFF", tostring(state.applied), tostring(state.backedUp)))
    log(string.format("Catalog: %d armor, %d weapons from %d sources (%d passports seen)",
        #cat.armor, #cat.weapon, stats.sources, stats.seen))
    for _, kind in ipairs({ "armor", "weapon" }) do
        local lastGroup = nil
        log("--- " .. kind .. " ---")
        for _, r in ipairs(cat[kind]) do
            if r.group ~= lastGroup then log("  [" .. r.group .. "]"); lastGroup = r.group end
            log("    " .. r.label .. "   <" .. r.keyClass .. ">")
        end
    end
    cat, armorArr, weaponArr = nil, nil, nil
    flushLua()  -- drop handles into the live lists now, while they are still valid
    log("================ end of scan ================")
end

---------------------------------------------------------------------------
-- on-screen message
---------------------------------------------------------------------------
local toast = { widget = nil, text = nil, token = 0 }

local function makeToastWidget(pc)
    local wbl = StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary")
    local uwClass = StaticFindObject("/Script/UMG.UserWidget")
    local treeClass = StaticFindObject("/Script/UMG.WidgetTree")
    local textClass = StaticFindObject("/Script/UMG.TextBlock")
    if not (valid(wbl) and valid(uwClass) and valid(treeClass) and valid(textClass)) then
        error("UMG classes not found")
    end
    local w = wbl:Create(pc, uwClass, pc)
    if not valid(w) then error("Create returned nothing") end
    local tree = StaticConstructObject(treeClass, w, FName("FL_WidgetTree"))
    w.WidgetTree = tree
    local t = StaticConstructObject(textClass, tree, FName("FL_ToastText"))
    tree.RootWidget = t
    pcall(function() t.Font.Size = 22 end)
    pcall(function() t:SetShadowOffset({ X = 2, Y = 2 }) end)
    pcall(function() t:SetShadowColorAndOpacity({ R = 0, G = 0, B = 0, A = 0.9 }) end)
    pcall(function() t:SetJustification(1) end)
    return w, t
end

local function showToast(msg, color)
    log(msg)
    if Cfg.ShowToast == false then return end
    local pc = FindFirstOf("PlayerController")
    local ok, err = pcall(function()
        if not valid(toast.widget) or not valid(toast.text) then
            toast.widget, toast.text = makeToastWidget(pc)
        end
        local w, t = toast.widget, toast.text
        t:SetText(FText(msg))
        pcall(function() t:SetColorAndOpacity({ SpecifiedColor = color, ColorUseRule = 0 }) end)
        if not w:IsInViewport() then w:AddToViewport(9999) end
        pcall(function()
            w:SetAnchorsInViewport({ Minimum = { X = 0.5, Y = 0.16 }, Maximum = { X = 0.5, Y = 0.16 } })
            w:SetAlignmentInViewport({ X = 0.5, Y = 0.5 })
        end)
    end)
    if not ok then
        if not toast.warned then toast.warned = true; log("On-screen message failed: " .. tostring(err)) end
        return
    end
    toast.token = toast.token + 1
    local my = toast.token
    ExecuteWithDelay(math.floor((Cfg.ToastSeconds or 2.5) * 1000), function()
        ExecuteInGameThread(function()
            if toast.token == my and valid(toast.widget) then pcall(function() toast.widget:RemoveFromParent() end) end
        end)
    end)
end

---------------------------------------------------------------------------
-- keys and loop
---------------------------------------------------------------------------
RegisterKeyBind(Cfg.Keys.Toggle, function()
    ExecuteInGameThread(function()
        enabled = not enabled
        local reopen = screenOpen() and " - reopen the loadout screen" or ""
        if enabled then
            if screenExists() then
                local ok, r = pcall(apply, "F6")
                if not ok then log("Apply failed: " .. tostring(r)) end
                if ok and r == false then reopen = " (fills in when free mode loads)" end
            else
                -- not in the free mode menu: build it later, when the loadout screen is around
                state.applied = false
                reopen = " (fills in at the loadout screen)"
            end
            showToast("Full loadout ON" .. reopen, { R = 0.4, G = 1.0, B = 0.4, A = 1 })
        else
            local ok, r = pcall(restore)
            if not ok then log("Restore failed: " .. tostring(r)) end
            showToast("Full loadout OFF (original list)" .. reopen, { R = 1.0, G = 0.45, B = 0.35, A = 1 })
        end
        flushLua()
    end)
end)

RegisterKeyBind(Cfg.Keys.Scan, Cfg.Keys.ScanModifiers, function()
    ExecuteInGameThread(function()
        safe("Scan", scan)
        showToast("Loadout scan written to UE4SS.log", { R = 0.6, G = 0.8, B = 1.0, A = 1 })
        flushLua()
    end)
end)

---------------------------------------------------------------------------
-- loadout screen hooks: run right before the screen builds its list, and log what happens
---------------------------------------------------------------------------
local screenHook = { done = false, calls = 0 }

local function countsLine(gi)
    local a, w = invCounts(gi, Cfg.InventoryVar)
    local s = string.format("inventory %d/%d", a, w)
    local da = currentTierAsset(gi)
    if da then
        local da_a, da_w = invCounts(da, Cfg.BackupVar)
        s = s .. string.format(", %s %d/%d", nameOf(da), da_a, da_w)
    end
    return s
end

local function onScreen(fn, pre, ctx)
    local gi = gameInstance()
    if not gi then return end
    if fn == "Construct" and pre then screenHook.calls = 0 end
    screenHook.calls = screenHook.calls + 1
    if screenHook.calls <= Cfg.ScreenHookLogLimit then
        local extra = ""
        if not pre then
            pcall(function()
                local w = ctx:get()
                extra = ", list shows " .. tostring(w.Player_Items_List:GetNumItems())
            end)
        end
        log(string.format("Screen %s %s: %s%s", fn, pre and "start" or "end", countsLine(gi), extra))
    end
    -- right before the screen builds: make sure the live inventory holds the full list
    if pre and enabled and state.applied and state.expected and state.daObj and valid(state.daObj) then
        local a, w = invCounts(gi, Cfg.InventoryVar)
        if a ~= state.expected.armor or w ~= state.expected.weapon then
            copyInventory(gi, Cfg.InventoryVar, state.daObj, Cfg.BackupVar)
            log(string.format("  refilled inventory before %s: %d/%d", fn, invCounts(gi, Cfg.InventoryVar)))
        end
    end
end

local function tryHookScreen()
    if screenHook.done then return end
    local w = nil
    for _, x in ipairs(FindAllOf(Cfg.ScreenClass) or {}) do
        if valid(x) then w = x; break end
    end
    if not w then return end
    screenHook.done = true
    local full = ""
    pcall(function() full = w:GetClass():GetFullName() end)
    local path = string.match(full, "%s(%S+)$")
    if not path then log("Screen class path not found (" .. tostring(full) .. ")"); return end
    for _, fn in ipairs(Cfg.ScreenHookFunctions) do
        local name = fn
        local ok, err = pcall(RegisterHook, path .. ":" .. name,
            function(ctx) safe("Screen hook", onScreen, name, true, ctx); flushLua() end,
            function(ctx) safe("Screen hook", onScreen, name, false, ctx); flushLua() end)
        log((ok and "Hooked " or "Could not hook ") .. path .. ":" .. name .. (ok and "" or (": " .. tostring(err))))
    end
end

LoopAsync(1000, function()
    ExecuteInGameThread(function()
        flushLua()
        safe("Screen hook setup", tryHookScreen)
        -- Build the list once, while the loadout screen exists. After that the screen hook puts it back
        -- each time the screen opens, so nothing is rebuilt on level changes or during battles.
        if not enabled or state.applied then return end
        local gi = gameInstance()
        if not gi or not screenExists() then return end
        local ok, aa, ww = pcall(inventoryArrays, gi)
        if not ok then return end
        local n = arrNum(aa) + arrNum(ww)
        aa, ww = nil, nil  -- let flushLua drop these handles before the lists change
        if n > 0 then safe("Apply", apply, "auto") end
        flushLua()
    end)
    return false
end)

log("v1.0.2 loaded. F6 = full loadout on/off, Shift+F5 = scan to UE4SS.log")
